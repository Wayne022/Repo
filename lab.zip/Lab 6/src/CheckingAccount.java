public class CheckingAccount extends BankAccount {

   
    private static final double FEE = 0.15; // clears check 

  
    public CheckingAccount(String name, double initialAmount) {
       
    	
    	super(name, initialAmount);// adds "-10" to the account number
        // Append "-10" to the account number (via mutator, since it's private in superclass)
       
        
    	setAccountNumber(getAccountNumber() + "-10");
    }

    
    public boolean withdraw(double amount) {
       
     
    	double totalAmount = amount + FEE;  // Add the check clearing fee to the withdrawal amount
      
       
    	return super.withdraw(totalAmount);// calls withdraw method 
    }
}
