public class SavingsAccount extends BankAccount {

    
    private double rate = 0.025; // 2.5% interest rate

    
    private int savingsNumber = 0;// savings acct #

 
    private String accountNumber;

    
    public SavingsAccount(String name, double initialBalance) {
        super(name, initialBalance);
        this.accountNumber = super.getAccountNumber() + "-" + savingsNumber;// creates new acct
    }

   

    public void postInterest() {
        double monthlyRate = rate / 12;
        double interest = getBalance() * monthlyRate;
        deposit(interest);// adds 1 months worth of interest
    }

    
   
    public String getAccountNumber() {
        return accountNumber;
    }

 
    public SavingsAccount(SavingsAccount originalAccount, double initialBalance) {
        super(originalAccount, initialBalance);
        this.savingsNumber = originalAccount.savingsNumber + 1;
        this.accountNumber = super.getAccountNumber() + "-" + this.savingsNumber;
    }// creates new saving acct 
}
