package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class TicketingOfficeTestStudent {

    @Test
    public void testConstructor() {
        TicketingOffice t = new TicketingOffice("Blue", 40, 20, "office.png");

        assertEquals("Blue", t.getColor());
        assertEquals(40, t.getLength(), 0.01);
        assertEquals(20, t.getWidth(), 0.01);
    }

    @Test
    public void testToString() {
        TicketingOffice t = new TicketingOffice("Blue", 40, 20, "office.png");
        assertTrue(t.toString().contains("Ticketing"));
    }
}