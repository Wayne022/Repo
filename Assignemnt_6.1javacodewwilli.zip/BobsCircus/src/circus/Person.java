/*
 * Class: CMSC203 
 * Instructor: Grigoriy Grinberg
 * Description: 
 * Due: 05/03/2026
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 * Print your Name here: Wayne Willis
 */






package circus;

public abstract class Person {

    private String name;
    private int age;
    private int yearsWorked;
    private String job;
    private String imagePath;

    public Person(String name, int age, int yearsWorked, String job, String imagePath) {
        this.name = name;
        this.age = age;
        this.yearsWorked = yearsWorked;
        this.job = job;
        this.imagePath = imagePath;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public int getYearsWorked() { return yearsWorked; }
    public String getJob() { return job; }
    public String getImagePath() { return imagePath; }

    public String toString() {
        return name + ", Age: " + age + ", Job: " + job;
    }
}