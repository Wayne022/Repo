/*
 * Class: CMSC203 
 * Instructor: Grigoriy Grinberg
 * Description: 
 * Due: 05/03/2026
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 * Print your Name here: Wayne Willis
 */





package circus;
public class Horse implements Animal {

    private String name, species, color, imagePath;
    private int age;

    public Horse(String name, int age, String species, String color, String imagePath) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
        this.imagePath = imagePath;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getSpecies() { return species; }
    public String getColor() { return color; }
    public String getImagePath() { return imagePath; }

    public void makeSound() {
        System.out.println(name + " neighs!");
    }

    public void move() {
        System.out.println(name + " gallops!");
    }

    public String toString() {
        return "Horse: " + name;
    }
}