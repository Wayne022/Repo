package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class ClerkTestStudent {

    @Test
    public void testConstructor() {
        Clerk c = new Clerk("John", 30, 5, "Ticket Clerk", "clerk.png");

        assertEquals("John", c.getName());
        assertEquals(30, c.getAge());
        assertEquals(5, c.getYearsWorked());
        assertEquals("Ticket Clerk", c.getJob());
    }

    @Test
    public void testToString() {
        Clerk c = new Clerk("John", 30, 5, "Ticket Clerk", "clerk.png");
        assertTrue(c.toString().contains("Clerk"));
    }
}