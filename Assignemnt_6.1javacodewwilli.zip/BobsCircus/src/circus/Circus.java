/*
 * Class: CMSC203 
 * Instructor: Grigoriy Grinberg
 * Description: 
 * Due: 05/03/2026
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 * Print your Name here: Wayne Willis
 */





package circus;
import java.util.*;

public class Circus {

    private ArrayList<Animal> animals = new ArrayList<>();
    private ArrayList<Person> persons = new ArrayList<>();
    private ArrayList<Building> buildings = new ArrayList<>();

    public void addAnimal(Animal a) { animals.add(a); }
    public void addPerson(Person p) { persons.add(p); }
    public void addBuilding(Building b) { buildings.add(b); }

    public ArrayList<Animal> getAnimals() { return animals; }
    public ArrayList<Person> getPersons() { return persons; }
    public ArrayList<Building> getBuildings() { return buildings; }

    public void displayAllAnimals() {
        for (Animal a : animals) System.out.println(a);
    }

    public void displayAllPersons() {
        for (Person p : persons) System.out.println(p);
    }

    public void displayAllBuildings() {
        for (Building b : buildings) System.out.println(b);
    }

    public void sortAnimalsByName() {
        animals.sort(Comparator.comparing(Animal::getName));
    }

    public void sortAnimalsByAge() {
        animals.sort(Comparator.comparingInt(Animal::getAge));
    }
}