/*
 * Class: CMSC203 
 * Instructor: Grigoriy Grinberg
 * Description: 
 * Due: 05/03/2026
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 * Print your Name here: Wayne Willis
 */




package circus;

public class TicketingOffice implements Building {

    private String color, imagePath;
    private double length, width;

    public TicketingOffice(String color, double length, double width, String imagePath) {
        this.color = color;
        this.length = length;
        this.width = width;
        this.imagePath = imagePath;
    }

    public String getColor() { return color; }
    public double getLength() { return length; }
    public double getWidth() { return width; }
    public String getImagePath() { return imagePath; }

    public String toString() {
        return "Ticketing Office";
    }
}