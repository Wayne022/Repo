package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class AcrobaticTestStudent {

    @Test
    public void testConstructor() {
        Acrobatic a = new Acrobatic("Lily", 25, 3, "Performer", "acro.png");

        assertEquals("Lily", a.getName());
        assertEquals(25, a.getAge());
        assertEquals(3, a.getYearsWorked());
        assertEquals("Performer", a.getJob());
    }

    @Test
    public void testToString() {
        Acrobatic a = new Acrobatic("Lily", 25, 3, "Performer", "acro.png");
        assertTrue(a.toString().contains("Acrobatic"));
    }
}