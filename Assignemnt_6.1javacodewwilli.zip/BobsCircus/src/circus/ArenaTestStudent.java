package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class ArenaTestStudent {

    @Test
    public void testConstructor() {
        Arena a = new Arena("Red", 100, 50, "arena.png");

        assertEquals("Red", a.getColor());
        assertEquals(100, a.getLength(), 0.01);
        assertEquals(50, a.getWidth(), 0.01);
    }

    @Test
    public void testToString() {
        Arena a = new Arena("Red", 100, 50, "arena.png");
        assertTrue(a.toString().contains("Arena"));
    }
}