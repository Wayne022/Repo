package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class LionTestStudent {

    @Test
    public void testConstructor() {
        Lion l = new Lion("Simba", 5, "Lion", "Golden", "lion.png");

        assertEquals("Simba", l.getName());
        assertEquals(5, l.getAge());
        assertEquals("Lion", l.getSpecies());
        assertEquals("Golden", l.getColor());
    }

    @Test
    public void testToString() {
        Lion l = new Lion("Simba", 5, "Lion", "Golden", "lion.png");
        assertTrue(l.toString().contains("Simba"));
    }
}