/*
 * Class: CMSC203 
 * Instructor: Grigoriy Grinberg
 * Description: 
 * Due: 05/03/2026
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
 * Print your Name here: Wayne Willis
 */




package circus;

public interface Animal {
    String getName();
    int getAge();
    String getSpecies();
    String getColor();
    String getImagePath();

    void makeSound();
    void move();
}