package circus;

import static org.junit.Assert.*;
import org.junit.Test;

public class BirdTestStudent {

    @Test
    public void testConstructor() {
        Bird b = new Bird("Tweety", 2, "Parrot", "Yellow", "bird.png");

        assertEquals("Tweety", b.getName());
        assertEquals(2, b.getAge());
        assertEquals("Parrot", b.getSpecies());
        assertEquals("Yellow", b.getColor());
    }

    @Test
    public void testToString() {
        Bird b = new Bird("Tweety", 2, "Parrot", "Yellow", "bird.png");
        assertTrue(b.toString().contains("Tweety"));
    }
}