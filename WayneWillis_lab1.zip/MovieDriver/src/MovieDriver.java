import java.util.Scanner;

public class MovieDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String again;

       
        //input for movie info
        
        do {
            Movie movie = new Movie();

            System.out.print("Enter the name of a movie: ");
            movie.setTitle(input.nextLine());

            System.out.print("Enter the rating of the movie: ");
            movie.setRating(input.nextLine());

            System.out.print("Enter the number of tickets sold for this movie: ");
            movie.setSoldTickets(input.nextInt());
            input.nextLine(); // Clear newline

            System.out.println(movie);

            System.out.print("Do you want to enter another movie? (yes/no): ");
            again = input.nextLine();
        } while (again.equalsIgnoreCase("yes"));

        input.close();
    }
}
