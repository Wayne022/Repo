
public class HolidayBonus {

	 public static double[] calculateHolidayBonus(double[][] data) {
	        double[] bonuses = new double[data.length];

	        for (int row = 0; row < data.length; row++) {
	            double bonusTotal = 0;

	            for (int col = 0; col < data[row].length; col++) {

	                double highest = getHighestInColumn(data, col);
	                double lowest = getLowestInColumn(data, col);
	                double value = data[row][col];

	                if (value == highest)
	                    bonusTotal += 5000;
	                else if (value == lowest)
	                    bonusTotal += 1000;
	                else
	                    bonusTotal += 2000;
	            }

	            bonuses[row] = bonusTotal;
	        }

	        return bonuses;
	    }

	    public static double calculateTotalHolidayBonus(double[][] data) {
	        double[] bonuses = calculateHolidayBonus(data);
	        double total = 0;

	        for (double b : bonuses)
	            total += b;

	        return total;
	    }

	    private static double getHighestInColumn(double[][] data, int col) {
	        double highest = Double.NEGATIVE_INFINITY;

	        for (double[] row : data) {
	            if (col < row.length && row[col] > highest)
	                highest = row[col];
	        }
	        return highest;
	    }

	    private static double getLowestInColumn(double[][] data, int col) {
	        double lowest = Double.POSITIVE_INFINITY;

	        for (double[] row : data) {
	            if (col < row.length && row[col] < lowest)
	                lowest = row[col];
	        }
	        return lowest;
	    }
}
