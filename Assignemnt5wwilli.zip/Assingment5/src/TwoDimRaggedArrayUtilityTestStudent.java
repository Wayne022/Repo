import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;

public class TwoDimRaggedArrayUtilityTestStudent {

    // Test ragged array
    private double[][] data = {
            {1.0, 2.0, 3.0},
            {4.0, 5.0},
            {6.0, 7.0, 8.0, 9.0}
    };

    @Test
    public void testGetTotal() {
        double total = TwoDimRaggedArrayUtility.getTotal(data);
        assertEquals(45.0, total, 0.001);
    }

    @Test
    public void testGetAverage() {
        double avg = TwoDimRaggedArrayUtility.getAverage(data);
        assertEquals(45.0 / 9.0, avg, 0.001);
    }

    @Test
    public void testGetRowTotal() {
        assertEquals(6.0, TwoDimRaggedArrayUtility.getRowTotal(data, 0), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getRowTotal(data, 1), 0.001);
        assertEquals(30.0, TwoDimRaggedArrayUtility.getRowTotal(data, 2), 0.001);
    }

    @Test
    public void testGetColumnTotal() {
        assertEquals(1.0 + 4.0 + 6.0, TwoDimRaggedArrayUtility.getColumnTotal(data, 0), 0.001);
        assertEquals(2.0 + 5.0 + 7.0, TwoDimRaggedArrayUtility.getColumnTotal(data, 1), 0.001);
        assertEquals(3.0 + 8.0, TwoDimRaggedArrayUtility.getColumnTotal(data, 2), 0.001);
    }

    @Test
    public void testGetHighestInRow() {
        assertEquals(3.0, TwoDimRaggedArrayUtility.getHighestInRow(data, 0), 0.001);
        assertEquals(5.0, TwoDimRaggedArrayUtility.getHighestInRow(data, 1), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInRow(data, 2), 0.001);
    }

    @Test
    public void testGetLowestInRow() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInRow(data, 0), 0.001);
        assertEquals(4.0, TwoDimRaggedArrayUtility.getLowestInRow(data, 1), 0.001);
        assertEquals(6.0, TwoDimRaggedArrayUtility.getLowestInRow(data, 2), 0.001);
    }

    @Test
    public void testGetHighestInColumn() {
        assertEquals(6.0, TwoDimRaggedArrayUtility.getHighestInColumn(data, 0), 0.001);
        assertEquals(7.0, TwoDimRaggedArrayUtility.getHighestInColumn(data, 1), 0.001);
        assertEquals(8.0, TwoDimRaggedArrayUtility.getHighestInColumn(data, 2), 0.001);
    }

    @Test
    public void testGetLowestInColumn() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInColumn(data, 0), 0.001);
        assertEquals(2.0, TwoDimRaggedArrayUtility.getLowestInColumn(data, 1), 0.001);
        assertEquals(3.0, TwoDimRaggedArrayUtility.getLowestInColumn(data, 2), 0.001);
    }

    @Test
    public void testGetHighestInArray() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInArray(data), 0.001);
    }

    @Test
    public void testGetLowestInArray() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInArray(data), 0.001);
    }

    @Test
    public void testWriteReadFile() throws IOException {
        File file = new File("test_sales.txt");

        // write
        TwoDimRaggedArrayUtility.writeToFile(data, file);

        // read
        double[][] loaded = TwoDimRaggedArrayUtility.readFile(file);

        // verify a few key values
        assertEquals(1.0, loaded[0][0], 0.001);
        assertEquals(5.0, loaded[1][1], 0.001);
        assertEquals(9.0, loaded[2][3], 0.001);
    }
}


