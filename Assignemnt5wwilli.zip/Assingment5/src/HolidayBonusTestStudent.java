import static org.junit.Assert.*;
import org.junit.Test;

public class HolidayBonusTestStudent {

    // sample ragged sales data
    private double[][] data = {
            {1.0, 2.0, 3.0},
            {5.0, 1.0},
            {3.0, 9.0, 1.0, 4.0}
    };

    @Test
    public void testCalculateHolidayBonus() {
        double[] bonuses = HolidayBonus.calculateHolidayBonus(data);

        // Make sure array length matches number of stores
        assertEquals(3, bonuses.length);

        // You should adjust these expected values 
        // based on YOUR bonus rules in HolidayBonus.java
        // For now we just check that bonuses are not negative
        assertTrue(bonuses[0] >= 0);
        assertTrue(bonuses[1] >= 0);
        assertTrue(bonuses[2] >= 0);
    }

    @Test
    public void testCalculateTotalHolidayBonus() {
        double total = HolidayBonus.calculateTotalHolidayBonus(data);
        assertTrue(total >= 0);
    }
}
