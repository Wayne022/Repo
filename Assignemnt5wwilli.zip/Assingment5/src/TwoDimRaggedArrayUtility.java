import java.io.*;
import java.util.*;


public class TwoDimRaggedArrayUtility {

	
	public static double[][] readFile(File file) throws FileNotFoundException {
        ArrayList<double[]> rows = new ArrayList<>();
        Scanner input = new Scanner(file);

        while (input.hasNextLine()) {
            String line = input.nextLine().trim();
            if (line.isEmpty()) continue;

            String[] tokens = line.split(" ");
            double[] row = new double[tokens.length];

            for (int i = 0; i < tokens.length; i++) {
                row[i] = Double.parseDouble(tokens[i]);
            }
            rows.add(row);
        }

        input.close();

        return rows.toArray(new double[rows.size()][]);
    }

    public static void writeToFile(double[][] data, File outputFile) throws IOException {
        PrintWriter out = new PrintWriter(outputFile);

        for (double[] row : data) {
            for (int i = 0; i < row.length; i++) {
                out.print(row[i]);
                if (i < row.length - 1) out.print(" ");
            }
            out.println();
        }

        out.close();
    }

    public static double getTotal(double[][] data) {
        double total = 0;
        for (double[] row : data)
            for (double value : row)
                total += value;
        return total;
    }

    public static double getAverage(double[][] data) {
        double total = 0;
        int count = 0;

        for (double[] row : data)
            for (double value : row) {
                total += value;
                count++;
            }

        return total / count;
    }

    public static double getRowTotal(double[][] data, int row) {
        double total = 0;
        for (double value : data[row])
            total += value;
        return total;
    }

    public static double getColumnTotal(double[][] data, int col) {
        double total = 0;

        for (double[] row : data) {
            if (col < row.length)
                total += row[col];
        }

        return total;
    }

    public static double getHighestInArray(double[][] data) {
        double highest = data[0][0];

        for (double[] row : data)
            for (double value : row)
                if (value > highest)
                    highest = value;

        return highest;
    }

    public static double getLowestInArray(double[][] data) {
        double lowest = data[0][0];

        for (double[] row : data)
            for (double value : row)
                if (value < lowest)
                    lowest = value;

        return lowest;
    }
    
    
    
    public static double getHighestInRow(double[][] data, int row) {
        double max = data[row][0];
        for (int i = 1; i < data[row].length; i++) {
            if (data[row][i] > max) {
                max = data[row][i];
            }
        }
        return max;
    }

    public static double getLowestInRow(double[][] data, int row) {
        double min = data[row][0];
        for (int i = 1; i < data[row].length; i++) {
            if (data[row][i] < min) {
                min = data[row][i];
            }
        }
        return min;
    }
    
    
    public static double getHighestInColumn(double[][] data, int col) {
        double max = Double.NEGATIVE_INFINITY;

        for (int row = 0; row < data.length; row++) {
            if (col < data[row].length) { 
                if (data[row][col] > max) {
                    max = data[row][col];
                }
            }
        }
        return max;
}
    
    
    public static double getLowestInColumn(double[][] data, int col) {
        double min = Double.POSITIVE_INFINITY;

        for (int row = 0; row < data.length; row++) {
            if (col < data[row].length) { 
                if (data[row][col] < min) {
                    min = data[row][col];
                }
            }
        }
        return min;
    }

    
    
    
}