
public class SalesDataUtility {

    public static double getTotal(double[][] data) {
        double total = 0;
        for (double[] row : data) {
            for (double val : row) {
                total += val;
            }
        }
        return total;
    }

    public static double getAverage(double[][] data) {
        double total = 0;
        int count = 0;

        for (double[] row : data) {
            for (double val : row) {
                total += val;
                count++;
            }
        }
        return count == 0 ? 0 : total / count;
    }

    public static double getRowTotal(double[][] data, int row) {
        double total = 0;
        for (double val : data[row]) {
            total += val;
        }
        return total;
    }

    public static double getColumnTotal(double[][] data, int col) {
        double total = 0;
        for (int i = 0; i < data.length; i++) {
            if (col < data[i].length) {
                total += data[i][col];
            }
        }
        return total;
    }

    public static double getHighestInRow(double[][] data, int row) {
        double max = data[row][0];
        for (double val : data[row]) {
            if (val > max) {
                max = val;
            }
        }
        return max;
    }

    public static double getLowestInRow(double[][] data, int row) {
        double min = data[row][0];
        for (double val : data[row]) {
            if (val < min) {
                min = val;
            }
        }
        return min;
    }

    public static double getHighestInArray(double[][] data) {
        double max = data[0][0];
        for (double[] row : data) {
            for (double val : row) {
                if (val > max) {
                    max = val;
                }
            }
        }
        return max;
    }

    public static double getLowestInArray(double[][] data) {
        double min = data[0][0];
        for (double[] row : data) {
            for (double val : row) {
                if (val < min) {
                    min = val;
                }
            }
        }
        return min;
    }
}
