import java.util.Scanner;

public class SalesAppDriver {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter input file: ");
            String inputFile = scanner.nextLine();

            System.out.print("Enter output file: ");
            String outputFile = scanner.nextLine();

            double[][] data = SalesFileIO.readSalesData(inputFile);

            SalesFileIO.writeSummary(outputFile, data);

            System.out.println("Processing complete. Check output file.");

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        scanner.close();
    }
}