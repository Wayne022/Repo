import java.io.*;
import java.util.*;

public class SalesFileIO {

    public static double[][] readSalesData(String filename) throws IOException {
        List<double[]> rows = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));

        String line;
        while ((line = br.readLine()) != null) {
            String[] tokens = line.trim().split("\\s+");
            double[] row = new double[tokens.length];

            for (int i = 0; i < tokens.length; i++) {
                row[i] = Double.parseDouble(tokens[i]);
            }
            rows.add(row);
        }
        br.close();

        return rows.toArray(new double[rows.size()][]);
    }

    public static void writeSummary(String filename, double[][] data) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(filename));

        pw.println("Total sales: " + SalesDataUtility.getTotal(data));
        pw.println("Average sale: " + SalesDataUtility.getAverage(data));

        for (int i = 0; i < data.length; i++) {
            pw.println("Row " + i + " total: " + SalesDataUtility.getRowTotal(data, i));
        }

        int maxCols = 0;
        for (double[] row : data) {
            if (row.length > maxCols) {
                maxCols = row.length;
            }
        }

        for (int i = 0; i < maxCols; i++) {
            pw.println("Column " + i + " total: " + SalesDataUtility.getColumnTotal(data, i));
        }

        pw.close();
    }
}