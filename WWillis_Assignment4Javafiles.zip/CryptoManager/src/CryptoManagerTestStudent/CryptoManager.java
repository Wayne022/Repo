package CryptoManagerTestStudent;

import java.util.ArrayList;



/*
 * Class: CMSC203 
 * Instructor: Huseyin Aygun
 * Description: (Give a brief description for each Class)
 * Due: 10/12/25
 * Platform/compiler: Eclipse 
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Wayne Willis 
*/


















/**
 * This is a utility class that encrypts and decrypts a phrase using three
 * different approaches. 
 * 
 * The first approach is called the Vigenere Cipher.Vigenere encryption 
 * is a method of encrypting alphabetic text based on the letters of a keyword.
 * 
 * The second approach is Playfair Cipher. It encrypts two letters (a digraph) 
 * at a time instead of just one.
 * 
 * The third approach is Caesar Cipher. It is a simple replacement cypher. 
 * 
 * @author Huseyin Aygun
 * @version 8/3/2025
 */

public class CryptoManager { 

    private static final char LOWER_RANGE = ' ';
    private static final char UPPER_RANGE = '_';
    private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;
    // Use 64-character matrix (8X8) for Playfair cipher  
   
    @SuppressWarnings("unused")
	private static final String ALPHABET64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_";
    
    //error message if input is not within bounds 
    private static final String OUT_OF_BOUNDS = "The selected string is not within bounds, please Try again.";


    public static boolean isStringInBounds(String plainText) {
        for (int i = 0; i < plainText.length(); i++) {
            if (!(plainText.charAt(i) >= LOWER_RANGE && plainText.charAt(i) <= UPPER_RANGE)) {
                return false;
            }
        }
        return true;
    }

	/**
	 * Vigenere Cipher is a method of encrypting alphabetic text 
	 * based on the letters of a keyword. It works as below:
	 * 		Choose a keyword (e.g., KEY).
	 * 		Repeat the keyword to match the length of the plaintext.
	 * 		Each letter in the plaintext is shifted by the position of the 
	 * 		corresponding letter in the keyword (A = 0, B = 1, ..., Z = 25).
	 */   

    public static String vigenereEncryption(String plainText, String key) {
         //to be implemented by students
    	
    	if (plainText == null || key == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(plainText) || !isStringInBounds(key) || key.length() == 0)
            return OUT_OF_BOUNDS;

        StringBuilder out = new StringBuilder();
        int keyLen = key.length();
        for (int i = 0; i < plainText.length(); i++) {
            char p = plainText.charAt(i);
            char k = key.charAt(i % keyLen);

            // map to 0..RANGE-1 using ASCII offset
            int pIdx = p - LOWER_RANGE;
            int kIdx = k - LOWER_RANGE;

            int cIdx = (pIdx + kIdx) % RANGE;
            char cipherChar = (char)(cIdx + LOWER_RANGE);
            out.append(cipherChar);
        }
        return out.toString();
    }

    // Vigenere Decryption
    public static String vigenereDecryption(String encryptedText, String key) {
         //to be implemented by students
    	
    	if (encryptedText == null || key == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(encryptedText) || !isStringInBounds(key) || key.length() == 0)
            return OUT_OF_BOUNDS;

        StringBuilder out = new StringBuilder();
        int keyLen = key.length();
        for (int i = 0; i < encryptedText.length(); i++) {
            char c = encryptedText.charAt(i);
            char k = key.charAt(i % keyLen);

            int cIdx = c - LOWER_RANGE;
            int kIdx = k - LOWER_RANGE;

            int pIdx = ((cIdx - kIdx) % RANGE + RANGE) % RANGE; // keep non-negative
            char plainChar = (char)(pIdx + LOWER_RANGE);
            out.append(plainChar);
        }
        return out.toString();
    }


	/**
	 * Playfair Cipher encrypts two letters at a time instead of just one.
	 * It works as follows:
	 * A matrix (8X8 in our case) is built using a keyword
	 * Plaintext is split into letter pairs (e.g., ME ET YO UR).
	 * Encryption rules depend on the positions of the letters in the matrix:
	 *     Same row: replace each letter with the one to its right.
	 *     Same column: replace each with the one below.
	 *     Rectangle: replace each letter with the one in its own row but in the column of the other letter in the pair.
	 */    

    public static String playfairEncryption(String plainText, String key) {
         //to be implemented by students
    	
    	
    	if (plainText == null || key == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(plainText) || !isStringInBounds(key)) return OUT_OF_BOUNDS;

        // build 8x8 square using key then remaining ASCII chars in range
        char[][] square = new char[8][8];
        boolean[] used = new boolean[RANGE];
        ArrayList<Character> seq = new ArrayList<>();

        // put key chars first (ignore duplicates)
        for (int i = 0; i < key.length(); i++) {
            char kc = key.charAt(i);
            if (kc < LOWER_RANGE || kc > UPPER_RANGE) continue;
            int idx = kc - LOWER_RANGE;
            if (!used[idx]) {
                used[idx] = true;
                seq.add((char)(LOWER_RANGE + idx));
            }
        }
        // then add remaining chars in ASCII order
        for (int i = 0; i < RANGE; i++) {
            if (!used[i]) seq.add((char)(LOWER_RANGE + i));
        }
        // fill square row-major
        int pos = 0;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                square[r][c] = seq.get(pos++);
            }
        }

        // make digraphs with filler 'X' (or first allowed char if 'X' out of range)
        char filler = 'X';
        if (filler < LOWER_RANGE || filler > UPPER_RANGE) filler = (char) LOWER_RANGE;
        ArrayList<char[]> pairs = new ArrayList<>();
        int i = 0;
        while (i < plainText.length()) {
            char a = plainText.charAt(i);
            if (i + 1 >= plainText.length()) {
                pairs.add(new char[]{a, filler});
                i++;
            } else {
                char b = plainText.charAt(i + 1);
                if (a == b) {
                    pairs.add(new char[]{a, filler});
                    i++; // move by 1 so second char will be reprocessed
                } else {
                    pairs.add(new char[]{a, b});
                    i += 2;
                }
            }
        }

        // helper to find coordinates
        java.util.function.Function<Character, int[]> findPos = ch -> {
            for (int rr = 0; rr < 8; rr++) for (int cc = 0; cc < 8; cc++)
                if (square[rr][cc] == ch) return new int[]{rr, cc};
            return null;
        };

        // encrypt each pair
        StringBuilder out = new StringBuilder();
        for (char[] pair : pairs) {
            char a = pair[0], b = pair[1];
            int[] pa = findPos.apply(a);
            int[] pb = findPos.apply(b);
            int r1 = pa[0], c1 = pa[1], r2 = pb[0], c2 = pb[1];

            if (r1 == r2) {
                // same row -> right
                out.append(square[r1][(c1 + 1) % 8]);
                out.append(square[r2][(c2 + 1) % 8]);
            } else if (c1 == c2) {
                // same column -> down
                out.append(square[(r1 + 1) % 8][c1]);
                out.append(square[(r2 + 1) % 8][c2]);
            } else {
                // rectangle -> swap columns
                out.append(square[r1][c2]);
                out.append(square[r2][c1]);
            }
        }
        return out.toString();
    }

    // PLAYFAIR DECRYPTION
    public static String playfairDecryption(String encryptedText, String key) {
         //to be implemented by students
    	
    	if (encryptedText == null || key == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(encryptedText) || !isStringInBounds(key)) return OUT_OF_BOUNDS;

        // build same square as in encryption
        char[][] square = new char[8][8];
        boolean[] used = new boolean[RANGE];
        ArrayList<Character> seq = new ArrayList<>();
        for (int i = 0; i < key.length(); i++) {
            char kc = key.charAt(i);
            if (kc < LOWER_RANGE || kc > UPPER_RANGE) continue;
            int idx = kc - LOWER_RANGE;
            if (!used[idx]) {
                used[idx] = true;
                seq.add((char)(LOWER_RANGE + idx));
            }
        }
        for (int i = 0; i < RANGE; i++) if (!used[i]) seq.add((char)(LOWER_RANGE + i));
        int pos = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) square[r][c] = seq.get(pos++);

        // helper to find coordinates
        java.util.function.Function<Character, int[]> findPos = ch -> {
            for (int rr = 0; rr < 8; rr++) for (int cc = 0; cc < 8; cc++)
                if (square[rr][cc] == ch) return new int[]{rr, cc};
            return null;
        };

        char filler = 'X';
        if (filler < LOWER_RANGE || filler > UPPER_RANGE) filler = (char) LOWER_RANGE;

        StringBuilder out = new StringBuilder();
        for (int i = 0; i < encryptedText.length(); i += 2) {
            char a = encryptedText.charAt(i);
            char b = (i + 1 < encryptedText.length()) ? encryptedText.charAt(i + 1) : filler;
            int[] pa = findPos.apply(a);
            int[] pb = findPos.apply(b);
            int r1 = pa[0], c1 = pa[1], r2 = pb[0], c2 = pb[1];

            if (r1 == r2) {
                // same row -> left
                out.append(square[r1][(c1 + 7) % 8]);
                out.append(square[r2][(c2 + 7) % 8]);
            } else if (c1 == c2) {
                // same column -> up
                out.append(square[(r1 + 7) % 8][c1]);
                out.append(square[(r2 + 7) % 8][c2]);
            } else {
                // rectangle -> swap columns back
                out.append(square[r1][c2]);
                out.append(square[r2][c1]);
            }
        }
        return out.toString();
    	
    }

    /**
     * Caesar Cipher is a simple substitution cipher that replaces each letter in a message 
     * with a letter some fixed number of positions down the alphabet. 
     * For example, with a shift of 3, 'A' would become 'D', 'B' would become 'E', and so on.
     */    
 
    public static String caesarEncryption(String plainText, int key) {
	//to be implemented by students
    	
    	
    	if (plainText == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(plainText)) return OUT_OF_BOUNDS;

        StringBuilder out = new StringBuilder();
        int range = UPPER_RANGE - LOWER_RANGE + 1;
        int shift = ((key % range) + range) % range; // handle negative keys

        for (int i = 0; i < plainText.length(); i++) {
            char p = plainText.charAt(i);
            int idx = p - LOWER_RANGE;
            int cIdx = (idx + shift) % range;
            out.append((char) (cIdx + LOWER_RANGE));
        }
        return out.toString();
    }

    // Caesar Decryption
    public static String caesarDecryption(String encryptedText, int key) {
	//to be implemented by students
    	
    	
    	if (encryptedText == null) return OUT_OF_BOUNDS;
        if (!isStringInBounds(encryptedText)) return OUT_OF_BOUNDS;

        StringBuilder out = new StringBuilder();
        int range = UPPER_RANGE - LOWER_RANGE + 1;
        int shift = ((key % range) + range) % range;

        for (int i = 0; i < encryptedText.length(); i++) {
            char c = encryptedText.charAt(i);
            int idx = c - LOWER_RANGE;
            int pIdx = ((idx - shift) % range + range) % range;
            out.append((char) (pIdx + LOWER_RANGE));
        }
        return out.toString();
    	
    }    
    
    
    

}
