package CryptoManagerTestStudent;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CryptoManagerTestStudent {

	@Test
	void test() {
		fail("Not yet implemented");}
		
		@Test
	    public void testIsStringInBounds() {
	        assertTrue(CryptoManager.isStringInBounds("HELLO"));
	        assertFalse(CryptoManager.isStringInBounds("hello")); // lowercase is out of bounds
	    }

	    @Test
	    public void testCaesarEncryptionAndDecryption() {
	        String text = "HELLO";
	        int key = 5;
	        String encrypted = CryptoManager.caesarEncryption(text, key);
	        String decrypted = CryptoManager.caesarDecryption(encrypted, key);
	        assertEquals(text, decrypted);
	    }

	    @Test
	    public void testVigenereEncryptionAndDecryption() {
	        String text = "TEST";
	        String key = "KEY";
	        String encrypted = CryptoManager.vigenereEncryption(text, key);
	        String decrypted = CryptoManager.vigenereDecryption(encrypted, key);
	        assertEquals(text, decrypted);
	    }

	    @Test
	    public void testPlayfairEncryptionAndDecryption() {
	        String text = "HELLO";
	        String key = "KEY";
	        String encrypted = CryptoManager.playfairEncryption(text, key);
	        String decrypted = CryptoManager.playfairDecryption(encrypted, key);
	        assertEquals(text.length(), decrypted.length()); // same length after decrypt
	}

}
