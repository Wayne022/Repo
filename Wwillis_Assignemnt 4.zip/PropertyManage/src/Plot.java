
public class Plot {
	
	    

	   
	    private int x;      // x coordinate
	    private int y;      // y coordinate
	    private int width;
	    private int depth;

	    // Default constructor
	    public Plot() {
	        x = 0;
	        y = 0;
	        width = 1;
	        depth = 1;
	    }

	    // Parameterized constructor
	    public Plot(int xValue, int yValue, int widthValue, int depthValue) {
	        x = xValue;
	        y = yValue;
	        width = widthValue;
	        depth = depthValue;
	    }

	    // Copy constructor
	    public Plot(Plot otherPlot) {
	        this.x = otherPlot.x;
	        this.y = otherPlot.y;
	        this.width = otherPlot.width;
	        this.depth = otherPlot.depth;
	    }

	    // Getters
	    public int getX() {
	        return x;
	    }

	    public int getY() {
	        return y;
	    }

	    public int getWidth() {
	        return width;
	    }

	    public int getDepth() {
	        return depth;
	    }

	    // Setters
	    public void setX(int value) {
	        x = value;
	    }

	    public void setY(int value) {
	        y = value;
	    }

	    public void setWidth(int value) {
	        width = value;
	    }

	    public void setDepth(int value) {
	        depth = value;
	    }

	    // Method: check if plots overlap
	    public boolean overlaps(Plot otherPlot) {
	        if (this.x + this.width <= otherPlot.x ||
	            otherPlot.x + otherPlot.width <= this.x ||
	            this.y + this.depth <= otherPlot.y ||
	            otherPlot.y + otherPlot.depth <= this.y) {
	            return false;
	        }
	        return true;
	    }

	    // Method: check if one plot fully contains another
	    public boolean encompasses(Plot otherPlot) {
	        return (otherPlot.x >= this.x &&
	                otherPlot.y >= this.y &&
	                (otherPlot.x + otherPlot.width) <= (this.x + this.width) &&
	                (otherPlot.y + otherPlot.depth) <= (this.y + this.depth));
	    }

	    // toString method
	    public String toString() {
	        return x + "," + y + "," + width + "," + depth;
	    }
}
	


