
public class Property {
	
	    // Attributes
	    private String propertyName;  // Name of the property
	    private String city;          // City where the property is located
	    private double rentAmount;    // Monthly rent amount
	    private String owner;         // Name of the property owner
	    private Plot plot;            // The plot where the property is built

	  
	    public Property() {
	        propertyName = "";
	        city = "";
	        rentAmount = 0.0;
	        owner = "";
	        plot = new Plot();  // Default plot
	    }

	    public Property(String propertyNameValue, String cityValue, double rentValue, String ownerValue) {
	       
	    	propertyName = propertyNameValue;
	        city = cityValue;
	        rentAmount = rentValue;
	        owner = ownerValue;
	        plot = new Plot();  
	    }

	    public Property(String propertyNameValue, String cityValue, double rentValue, String ownerValue,
	                    int x, int y, int width, int depth) {
	       
	    	propertyName = propertyNameValue;
	        city = cityValue;
	        rentAmount = rentValue;
	        owner = ownerValue;
	        plot = new Plot(x, y, width, depth);
	    }

	    	    public Property(Property otherProperty) {
	        this.propertyName = otherProperty.propertyName;
	        this.city = otherProperty.city;
	        this.rentAmount = otherProperty.rentAmount;
	        this.owner = otherProperty.owner;
	        this.plot = new Plot(otherProperty.plot);
	    }

	    // Getters
	    public String getPropertyName() {
	        return propertyName;
	    }

	    public String getCity() {
	        return city;
	    }

	    public double getRentAmount() {
	        return rentAmount;
	    }

	    public String getOwner() {
	        return owner;
	    }

	    public Plot getPlot() {
	        return plot;
	    }

	    // Setters
	    public void setPropertyName(String value) {
	        propertyName = value;
	    }

	    public void setCity(String value) {
	        city = value;
	    }

	    public void setRentAmount(double value) {
	        rentAmount = value;
	    }

	    public void setOwner(String value) {
	        owner = value;
	    }

	    public void setPlot(int x, int y, int width, int depth) {
	        plot = new Plot(x, y, width, depth);
	    }

	    // toString method
	    public String toString() {
	        return propertyName + ", " + city + ", " + owner + ", " + rentAmount;
	    }
	}


