
public class ManagementCompany {
	
	  
	    private String name;                // Name of the management company
	    private String taxId;               // Tax ID of the company
	    private double mgmFeePer;           // Management fee percentage
	    private Property[] properties;      // Array of properties managed
	    private Plot plot;                  // The company’s plot of land

	   
	    public static final int MAX_PROPERTY = 5;  // Maximum number of properties allowed

	   
	    public ManagementCompany() {
	        name = "";
	        taxId = "";
	        mgmFeePer = 0.0;
	        plot = new Plot(0, 0, 10, 10);  // Default company plot
	        properties = new Property[MAX_PROPERTY];
	    }

	    public ManagementCompany(String nameValue, String taxIdValue, double mgmFeePerValue) {
	        name = nameValue;
	        taxId = taxIdValue;
	        mgmFeePer = mgmFeePerValue;
	        plot = new Plot(0, 0, 10, 10);
	        properties = new Property[MAX_PROPERTY];
	    }

	    public ManagementCompany(String nameValue, String taxIdValue, double mgmFeePerValue,
	                             int x, int y, int width, int depth) {
	        name = nameValue;
	        taxId = taxIdValue;
	        mgmFeePer = mgmFeePerValue;
	        plot = new Plot(x, y, width, depth);
	        properties = new Property[MAX_PROPERTY];
	    }

	
	    public ManagementCompany(ManagementCompany otherCompany) {
	        name = otherCompany.name;
	        taxId = otherCompany.taxId;
	        mgmFeePer = otherCompany.mgmFeePer;
	        plot = new Plot(otherCompany.plot);
	        properties = new Property[MAX_PROPERTY];
	        for (int i = 0; i < MAX_PROPERTY; i++) {
	            if (otherCompany.properties[i] != null) {
	                properties[i] = new Property(otherCompany.properties[i]);
	            }
	        }
	    }

	
	   
	    public int addProperty(Property property) {
	        if (property == null) {
	            return -2; // null property
	        }

	        for (int i = 0; i < MAX_PROPERTY; i++) {
	            if (properties[i] == null) {
	                properties[i] = property;
	                return i; // return index where added
	            }
	        }

	        return -1; 
	    }

	    // Calculates total rent of all properties
	    
	    public double totalRent() {
	        double total = 0.0;
	        for (int i = 0; i < MAX_PROPERTY; i++) {
	            if (properties[i] != null) {
	                total += properties[i].getRentAmount();
	            }
	        }
	        return total;
	    }

	    // Finds the property with the highest rent
	    
	    public Property maxRentProp() {
	        double maxRent = 0.0;
	        Property maxProp = null;

	        for (int i = 0; i < MAX_PROPERTY; i++) {
	            if (properties[i] != null && properties[i].getRentAmount() > maxRent) {
	                maxRent = properties[i].getRentAmount();
	                maxProp = properties[i];
	            }
	        }
	        return maxProp;
	    }

	    // Calculates the total management fee (as percentage of total rent)
	   
	    public double totalManagementFee() {
	        return totalRent() * (mgmFeePer / 100);
	    }

	    // Getters
	    public String getName() {
	        return name;
	    }

	    public Plot getPlot() {
	        return plot;
	    }

	    public String getTaxId() {
	        return taxId;
	    }

	    public double getMgmFeePer() {
	        return mgmFeePer;
	    }

	    // toString method
	    
	    public String toString() {
	        String result = "List of the properties for " + name + ", taxID: " + taxId + "\n";
	        result += "_____________________________________________________\n";
	        for (int i = 0; i < MAX_PROPERTY; i++) {
	            if (properties[i] != null) {
	                result += properties[i].toString() + "\n";
	            }
	        }
	        result += "_____________________________________________________\n";
	        result += "Total Management Fee: " + totalManagementFee();
	        return result;
	    }

		public Property getHighestRentProperty() {
			// TODO Auto-generated method stub
			return null;
		}

		public Object getPropertiesCount() {
			// TODO Auto-generated method stub
			return null;
		}

		public String getTotalRent() {
			// TODO Auto-generated method stub
			return null;
		}
	}


